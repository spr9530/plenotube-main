const express = require('express');
const { submitInstagramProfile } = require('./accounts.controller');

const account_router = express.Router();

account_router.post('/submit-profile-link/instagram', submitInstagramProfile);
// account_router.post('/submit-profile/youtube');
// account_router.post('/sbumit-profile/facebook');
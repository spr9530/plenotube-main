import React from 'react'
import SettingLayout from '../../layouts/settingLayout'

function Danger() {
  return (
    <SettingLayout>
        Danger zone
    </SettingLayout>
  )
}

export default Danger